#!/bin/sh
#DESCRIPTION=This script created by Levi45\nHdd Temp
hddtemp -q /dev/ide/host0/bus0/target0/lun0/disc
