# -*- coding: utf-8 -*-
# Coding: BY MOHAMED_OS

from datetime import datetime
from re import compile as reCompile

from Components.config import config
from Plugins.Extensions.IPTVPlayer.compat import e2Json_dumps
from Plugins.Extensions.IPTVPlayer.components.ihost import (CBaseHostClass,
                                                            CHostBase)
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import \
    GetIPTVNotify
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import \
    TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import (E2ColoR, printDBG,
                                                           printExc)
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
from Plugins.Extensions.IPTVPlayer.tools.manipulateStrings import (ensure_str,
                                                                   escape_str)


def gettytul():
    return f"Xtream {E2ColoR('cyan')}VOD{E2ColoR('white')}"


class XtreamVod(CBaseHostClass):

    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'xtreamvod', 'cookie': 'xtreamvod.cookie'})

        self.MAIN_URL = '{0}/player_api.php?username={1}&password={2}&action={3}'
        self.DEFAULT_ICON_URL = 'https://i.ibb.co/LYGhL5v/xtream.png'

        self.defaultParams = {'User-Agent': self.cm.getDefaultUserAgent('mobile'), 'X-Requested-With': 'com.sportstv20.app'}

    def listMainMenu(self, cItem):
        printDBG(f"XtreamVod.listMainMenu cItem[{cItem}]")
        multi_tab = self.cm.getXtreamConf()
        if len(multi_tab) == 0:
            self.addMarker({'title': 'Please configure xstream first', 'icon': self.DEFAULT_ICON_URL, 'desc': f'Please configure xstream first, (add user, pass, host in E2Iplayer params or add your config file in {config.plugins.iptvplayer.xtreamPath.value})'})
        elif len(multi_tab) == 1:
            params = dict(cItem)
            params.update({'icon': self.DEFAULT_ICON_URL, 'xuser': multi_tab[0][2], 'xpass': multi_tab[0][3], 'xhost': multi_tab[0][1]})
            self.listItems(params)
        else:
            for item in multi_tab:
                Url = '{0}/player_api.php?username={1}&password={2}'.format(item[1], item[2], item[3])

                sts, data = self.cm.getPageRequest(Url, self.defaultParams)
                if not sts:
                    continue
                user_info = data.get("user_info", {})

                expires = datetime.fromtimestamp(int(user_info.get("exp_date"))).strftime("%d-%m-%Y  %H:%M") if user_info.get("exp_date") else "Null"
                if user_info.get("status", "") == 'Active':
                    if item[0].startswith('http'):
                        title = f"{self.up.getDomain(item[1], True).split(':')[0]} | {E2ColoR('lime')}Expired{E2ColoR('white')}: {E2ColoR('cyan')}{expires}"
                    else:
                        title = f"{item[0]} | {E2ColoR('lime')}Expired{E2ColoR('white')}: {E2ColoR('cyan')}{expires}"
                    params = dict(cItem)
                    params.update({'category': 'listItems', 'title': title, 'icon': self.DEFAULT_ICON_URL, 'xuser': item[2], 'xpass': item[3], 'xhost': item[1]})
                    self.addDir(params)

    def listItems(self, cItem):
        printDBG(f"XtreamVod.listItems cItem[{cItem}]")

        MAIN_CAT_TAB = [
            {'category': 'search', 'title': _('Search'), 'search_item': True},
            {'category': 'search_history', 'title': _('Search history'), }]
        self.listsTab(MAIN_CAT_TAB, cItem)

        try:
            Url = self.MAIN_URL.format(cItem['xhost'], cItem['xuser'], cItem['xpass'], "get_vod_categories")

            sts, data = self.cm.getPageRequest(Url, self.defaultParams)
            if not sts:
                return

            self.addMarker({'title': _(f"{E2ColoR('lime')}Movies"), 'icon': cItem['icon'], 'desc': ''})
            params = dict(cItem)
            params.update({'category': 'movei', 'title': 'All', 'icon': cItem['icon'], 'category_id': '', 'xuser': cItem['xuser'], 'xpass': cItem['xpass'], 'xhost': cItem['xhost']})
            self.addDir(params)
            for item in data:
                params = dict(cItem)
                params.update({'category': 'movei', 'title': item['category_name'].strip(), 'icon': cItem['icon'], 'category_id': item['category_id'], 'xuser': cItem['xuser'], 'xpass': cItem['xpass'], 'xhost': cItem['xhost']})
                self.addDir(params)
        except Exception:
            printExc('Cannot parse received data !')

        try:
            Url = self.MAIN_URL.format(cItem['xhost'], cItem['xuser'], cItem['xpass'], "get_series_categories")

            sts, data = self.cm.getPageRequest(Url, self.defaultParams)
            if not sts:
                return

            self.addMarker({'title': _(f"{E2ColoR('lime')}Tv Series"), 'icon': cItem['icon'], 'desc': ''})
            params = dict(cItem)
            params.update({'category': 'serie', 'title': 'All', 'icon': cItem['icon'], 'category_id': '', 'xuser': cItem['xuser'], 'xpass': cItem['xpass'], 'xhost': cItem['xhost']})
            self.addDir(params)
            for item in data:
                params = dict(cItem)
                params.update({'category': 'serie', 'title': item['category_name'].strip(), 'icon': cItem['icon'], 'category_id': item['category_id'], 'xuser': cItem['xuser'], 'xpass': cItem['xpass'], 'xhost': cItem['xhost']})
                self.addDir(params)
        except Exception:
            printExc('Cannot parse received data !')

    def ShowMovei(self, cItem):
        printDBG(f"XtreamVod.ShowMovei cItem[{cItem}]")

        Url = self.MAIN_URL.format(cItem['xhost'], cItem['xuser'], cItem['xpass'], f"get_vod_streams&category_id={str(cItem['category_id'])}")

        sts, data = self.cm.getPageRequest(Url, self.defaultParams)
        if not sts:
            return

        try:
            for item in data:
                tmpUrl = f"{cItem['xhost']}/movie/{cItem['xuser']}/{cItem['xpass']}/{str(item['stream_id'])}.{item['container_extension']}"

                stream_icon = item.get("stream_icon", cItem['icon'])
                rating = str(item.get("rating", ""))
                plot = str(item.get("plot", ""))
                genre = str(item.get("genre", ""))

                releaseDate = (
                    item.get("releaseDate") or
                    item.get("release_date") or
                    item.get("releasedate") or
                    ""
                )
                tmpYear = str(releaseDate) if releaseDate is not None else ""

                desc = {'rating': rating, 'genre': genre, 'plot': plot, 'year': self.cm.ph.getSearchGroups(tmpYear, '''(\d{4})''')[0]}
                info = self.ph.std_title(ensure_str(item['name']), desc=desc, with_ep=True)
                title = info.get('title_display')
                desc = info.get('desc')

                sUrl = self.MAIN_URL.format(cItem['xhost'], cItem['xuser'], cItem['xpass'], f"get_vod_info&vod_id={str(item['stream_id'])}")
                params = dict(cItem)
                params.update({'good_for_fav': True, 'EPG': True, 'title': title, 'icon': stream_icon, 'url': tmpUrl, 'url_inf': sUrl, 'desc': desc})
                self.addVideo(params)
        except Exception:
            printExc('Cannot parse received data !')

    def ShowSerie(self, cItem):
        printDBG(f"XtreamVod.ShowSerie cItem[{cItem}]")

        Url = self.MAIN_URL.format(cItem['xhost'], cItem['xuser'], cItem['xpass'], f"get_series&category_id={str(cItem['category_id'])}")

        sts, data = self.cm.getPageRequest(Url, self.defaultParams)
        if not sts:
            return

        try:
            for item in data:

                stream_icon = item.get("cover", cItem['icon'])
                rating = str(item.get("rating", ""))
                plot = str(item.get("plot", ""))
                genre = str(item.get("genre", ""))

                releaseDate = (
                    item.get("releaseDate") or
                    item.get("release_date") or
                    item.get("releasedate") or
                    ""
                )
                tmpYear = str(releaseDate) if releaseDate is not None else ""

                desc = {'rating': rating, 'genre': genre, 'plot': plot, 'year': self.cm.ph.getSearchGroups(tmpYear, '''(\d{4})''')[0]}
                info = self.ph.std_title(ensure_str(item['name']), desc=desc, with_ep=True)
                title = info.get('title_display')
                desc = info.get('desc')

                sUrl = self.MAIN_URL.format(cItem['xhost'], cItem['xuser'], cItem['xpass'], f"get_series_info&series_id={str(item['series_id'])}")
                params = dict(cItem)
                params.update({'category': 'listSeason', 'good_for_fav': True, 'EPG': True, 'title': title, 'icon': stream_icon, 'url': item['series_id'], 'url_inf': sUrl, 'desc': desc, 'xuser': cItem['xuser'], 'xpass': cItem['xpass'], 'xhost': cItem['xhost']})
                self.addDir(params)
        except Exception:
            printExc('Cannot parse received data !')

    def exploreItems(self, cItem):
        printDBG(f"XtreamVod.exploreItems cItem[{cItem}]")

        sUrl = self.MAIN_URL.format(cItem['xhost'], cItem['xuser'], cItem['xpass'], f"get_series_info&series_id={cItem['url']}")

        sts, data = self.cm.getPageRequest(sUrl, self.defaultParams)
        if not sts:
            return

        try:
            tmp = reCompile('''['"]episodes['"]:\s?\{(.*)''').findall(e2Json_dumps(data))
            tmp = reCompile('''['"]id['"]:\s?['"]([^"^']+?)['"].+?['"]title['"]:\s?['"]([^"^']+?)['"].+?['"]container_extension['"]:\s?['"]([^"^']+?)['"]''').findall(tmp[0])
            for (sID, title, extension) in tmp:
                tmpUrl = f"{cItem['xhost']}/series/{cItem['xuser']}/{cItem['xpass']}/{sID}.{extension}"

                info = self.ph.std_title(escape_str(title), with_ep=True)
                title = info.get('title_display')
                otherInfo = f"{info.get('desc')}\n{cItem['desc']}"

                params = dict(cItem)
                params.update({'good_for_fav': True, 'EPG': True, 'title': title, 'icon': cItem['icon'], 'url': tmpUrl, 'desc': otherInfo})
                self.addVideo(params)
        except Exception:
            printExc('Cannot parse received data !')

    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG(f"XtreamVod.listSearchResult cItem[{cItem}], searchPattern[{searchPattern}] searchType[{searchType}]")

        if searchType == 'movies':
            try:
                sUrl = self.MAIN_URL.format(cItem['xhost'], cItem['xuser'], cItem['xpass'], "get_vod_streams")

                sts, data = self.cm.getPageRequest(sUrl, self.defaultParams)
                if not sts:
                    return

                for item in data:
                    if searchPattern.lower() in item['name'].lower():
                        tmpUrl = f"{cItem['xhost']}/movie/{cItem['xuser']}/{cItem['xpass']}/{str(item['stream_id'])}.{item['container_extension']}"

                        stream_icon = item.get("stream_icon", cItem['icon'])
                        rating = str(item.get("rating", ""))
                        plot = str(item.get("plot", ""))
                        genre = str(item.get("genre", ""))

                        releaseDate = (
                            item.get("releaseDate") or
                            item.get("release_date") or
                            item.get("releasedate") or
                            ""
                        )
                        tmpYear = str(releaseDate) if releaseDate is not None else ""

                        desc = {'rating': rating, 'genre': genre, 'plot': plot, 'year': self.cm.ph.getSearchGroups(tmpYear, '''(\d{4})''')[0]}
                        info = self.ph.std_title(ensure_str(item['name']), desc=desc, with_ep=True)
                        title = info.get('title_display')
                        desc = info.get('desc')

                        params = dict(cItem)
                        params.update({'good_for_fav': True, 'EPG': True, 'title': title, 'icon': stream_icon, 'url': tmpUrl, 'url_inf': sUrl, 'desc': desc})
                        self.addVideo(params)
            except:
                printExc('Cannot parse received data !')

        elif searchType == 'series':
            try:
                sUrl = self.MAIN_URL.format(cItem['xhost'], cItem['xuser'], cItem['xpass'], "get_series")

                sts, data = self.cm.getPageRequest(sUrl, self.defaultParams)
                if not sts:
                    return

                for item in data:
                    if searchPattern.lower() in item['name'].lower():

                        stream_icon = item.get("cover", cItem['icon'])
                        rating = str(item.get("rating", ""))
                        plot = str(item.get("plot", ""))
                        genre = str(item.get("genre", ""))

                        releaseDate = (
                            item.get("releaseDate") or
                            item.get("release_date") or
                            item.get("releasedate") or
                            ""
                        )
                        tmpYear = str(releaseDate) if releaseDate is not None else ""

                        desc = {'rating': rating, 'genre': genre, 'plot': plot, 'year': self.cm.ph.getSearchGroups(tmpYear, '''(\d{4})''')[0]}
                        info = self.ph.std_title(ensure_str(item['name']), desc=desc, with_ep=True)
                        title = info.get('title_display')
                        desc = info.get('desc')

                        sUrl = self.MAIN_URL.format(cItem['xhost'], cItem['xuser'], cItem['xpass'], f"get_series_info&series_id={str(item['series_id'])}")
                        params = dict(cItem)
                        params.update({'category': 'listSeason', 'good_for_fav': True, 'EPG': True, 'title': title, 'icon': stream_icon, 'url': item['series_id'], 'url_inf': sUrl, 'desc': desc, 'xuser': cItem['xuser'], 'xpass': cItem['xpass'], 'xhost': cItem['xhost']})
                        self.addDir(params)
            except:
                printExc('Cannot parse received data !')

    def getLinksForVideo(self, cItem):
        printDBG(f"XtreamVod.getLinksForVideo [{cItem}]")
        urlTab = []

        urlTab.append({'name': '', 'url': strwithmeta(cItem['url'], {'User-Agent': self.defaultParams['User-Agent']}), 'need_resolve': 0})

        return urlTab

    def getVideoLinks(self, videoUrl):
        printDBG(f"XtreamVod.getVideoLinks [{videoUrl}]")

        if self.cm.isValidUrl(videoUrl):
            return self.up.getVideoLinkExt(videoUrl)

    def getArticleContent(self, cItem):
        printDBG(f"XtreamVod.getArticleContent [{cItem}]")
        otherInfo = {}

        sts, data = self.cm.getPageRequest(cItem['url_inf'])
        if not sts:
            return False

        try:
            tmp = data.get('info', [])
            desc = tmp.get('plot', '')
            if tmp.get('age', '') != '':
                otherInfo['age_limit'] = tmp.get('age', '')
            if tmp.get('country', '') != '':
                otherInfo['country'] = tmp.get('country', '')
            if tmp.get('genre', '') != '':
                otherInfo['genre'] = tmp.get('genre', '')
            if tmp.get('duration', '') != '':
                otherInfo['duration'] = tmp.get('duration', '')
            if tmp.get('episode_run_time', '0') != '0':
                otherInfo['duration'] = tmp.get('episode_run_time', '')
            if tmp.get('releasedate', '') != '':
                otherInfo['year'] = tmp.get('releasedate', '')
            if tmp.get('releaseDate', '') != '':
                otherInfo['year'] = tmp.get('releasedate', '')
            if tmp.get('rating', '') != '':
                otherInfo['rating'] = tmp.get('rating', '')
            if tmp.get('cast', '') != '':
                otherInfo['cast'] = tmp.get('cast', '')
            if tmp.get('director', '') != '':
                otherInfo['director'] = tmp.get('director', '')

            return [{'title': cItem['title'], 'text': desc, 'images': [{'title': '', 'url': cItem['icon']}], 'other_info': otherInfo}]
        except Exception:
            GetIPTVNotify().push('Info not available ...!', 'error', 5)

    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('handleService start')

        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        printDBG(f"handleService: |||||||||||||||||||||||||||||||||||| name[{name}], category[{category}] ")
        self.currList = []

    # MAIN MENU
        if name == None and category == '':
            self.listMainMenu({'name': 'category', 'type': 'category'})
        elif category == 'listItems':
            self.listItems(self.currItem)
        elif category == 'movei':
            self.ShowMovei(self.currItem)
        elif category == 'serie':
            self.ShowSerie(self.currItem)
        elif category == 'listSeason':
            self.exploreItems(self.currItem)
    # SEARCH
        elif category in ["search", "search_next_page"]:
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
    # HISTORIA SEARCH
        elif category == "search_history":
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):

    def __init__(self):
        CHostBase.__init__(self, XtreamVod(), True, [])

    def getSearchTypes(self):
        searchTypesOptions = []
        searchTypesOptions.append(("Movies", "movies"))
        searchTypesOptions.append(("Tv Series", "series"))
        return searchTypesOptions

    def withArticleContent(self, cItem):
        if cItem['type'] != 'video' and cItem['category'] != 'exploreItems':
            return False
        return True
