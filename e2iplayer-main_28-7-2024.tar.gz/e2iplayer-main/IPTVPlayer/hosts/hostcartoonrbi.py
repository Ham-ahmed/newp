# -*- coding: utf-8 -*-
# Coding: BY MOHAMED_OS

from Plugins.Extensions.IPTVPlayer.components.ihost import (CBaseHostClass,
                                                            CHostBase)
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import \
    TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import (E2ColoR, printDBG,
                                                           printExc)


def GetConfigList():
    optionList = []
    return optionList


def gettytul():
    return 'CartoonArbi'


class CartoonArbi(CBaseHostClass):

    def __init__(self):
        CBaseHostClass.__init__(self, {'cookie': 'arteenz.cookie'})

        self.MAIN_URL = 'https://www.arteenz.com/'
        self.DEFAULT_ICON_URL = 'https://i.ibb.co/6nsRSXN/cartoonrbi.png'

        self.HEADER = self.cm.getDefaultHeader()
        self.AJAX_HEADER = self.HEADER
        self.AJAX_HEADER.update({'X-Requested-With': 'XMLHttpRequest'})
        self.defaultParams = {'header': self.HEADER, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}

    def getPage(self, baseUrl, addParams={}, post_data=None):
        if addParams == {}:
            addParams = dict(self.defaultParams)

        sts, data = self.cm.getPage(self.cm.ph.stdUrl(baseUrl), addParams, post_data)
        return sts, data

    def listMainMenu(self, cItem):
        printDBG("CartoonArbi.listMainMenu")
        MAIN_CAT_TAB = [
            {'category': 'show_movies', 'title': _('أفـــلام'), 'icon': self.DEFAULT_ICON_URL, 'url': self.getFullUrl('/films.html')},
            {'category': 'show_series', 'title': _('مســلســلات'), 'icon': self.DEFAULT_ICON_URL, 'url': self.getFullUrl('/cats.html')}]
        self.listsTab(MAIN_CAT_TAB, cItem)

    def listItems(self, cItem, nextCategory):
        printDBG(f"CartoonArbi.listItems cItem[{cItem}]")
        page = cItem.get('page', 1)

        sts, data = self.getPage(cItem['url'])
        if not sts:
            return

        nextPage = self.cm.ph.getDataBeetwenMarkers(data, ('current', '>'), ('</a>', '<a href'), True)[1]
        nextPage = self.getFullUrl(self.ph.search(nextPage, self.ph.A_HREF_URI_RE)[1])

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('blocks2', '>'), ('footer', '>'), True)[1]
        tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, ('cartoon_cat_pic', '>'), ('cartoon_cat', '>'))
        for item in tmp:
            icon = self.getFullIconUrl(self.ph.search(item, self.ph.IMAGE_SRC_URI_RE)[1])
            url = self.getFullUrl(self.ph.search(item, self.ph.A_HREF_URI_RE)[1])
            title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''title=['"]([^"^']+?)['"]''')[0])

            info = self.ph.std_title(title, with_ep=True)
            if title != '':
                title = info['title_display']
            desc = info['desc']

            params = dict(cItem)
            params.update({'category': nextCategory, 'good_for_fav': True, 'EPG': True, 'title': title, 'url': url, 'icon': self.cm.ph.stdUrl(icon), 'desc': desc})
            self.addDir(params)

        if nextPage != '':
            params = dict(cItem)
            params.update({'title': _("Next page"), 'url': nextPage, 'page': page + 1})
            self.addDir(params)

    def exploreItems(self, cItem):
        printDBG(f"CartoonArbi.exploreItems cItem[{cItem}]")

        sts, data = self.getPage(cItem['url'])
        if not sts:
            return
        cItem['prev_url'] = cItem['url']

        if any(x in cItem['url'] for x in ['cartooncat', 'cartoonpagecat']):
            page = cItem.get('page', 1)

            nextPage = self.cm.ph.getDataBeetwenMarkers(data, ('current', '>'), ('<div', 'style', '>'), True)[1]
            nextPage = self.getFullUrl(self.ph.search(nextPage, self.ph.A_HREF_URI_RE)[1])

            tmp = self.cm.ph.getDataBeetwenMarkers(data, ('<div', 'blocks', '>'), ('pagination', '>'), True)[1]
            desc = self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('block_body_story', '>'), ('</div', '>'), False)[1])

            tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, ('cartoon_eps_pic', '>'), ('cartoon_eps_name', '>'))
            for item in tmp:
                icon = self.getFullIconUrl(self.ph.search(item, self.ph.IMAGE_SRC_URI_RE)[1])
                url = self.getFullUrl(self.ph.search(item, self.ph.A_HREF_URI_RE)[1])
                title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''title=['"]([^"^']+?)['"]''')[0])

                info = self.ph.std_title(title, with_ep=True)
                if title != '':
                    title = info['title_display']
                otherInfo = f"{info['desc']}\n{desc}"

                params = dict(cItem)
                params.update({'good_for_fav': True, 'EPG': True, 'title': title, 'url': url, 'icon': self.cm.ph.stdUrl(icon), 'desc': otherInfo})
                self.addVideo(params)

            if nextPage != '':
                params = dict(cItem)
                params.update({'title': _("Next page"), 'url': nextPage, 'page': page + 1})
                self.addMore(params)
        else:

            params = dict(cItem)
            params.update({'good_for_fav': True, 'EPG': True, 'title': cItem['title'], 'url': cItem['url'], 'icon': cItem['icon'], 'desc': ''})
            self.addVideo(params)

    def getLinksForVideo(self, cItem):
        printDBG(f"CartoonArbi.getLinksForVideo [{cItem}]")
        urlTab = []
        sUrl = cItem['url'].replace("cartoon", "watch-")

        sts, data = self.getPage(sUrl)
        if not sts:
            return

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('<div', '>', 'servers'), ('<div', '>', 'videoshow'), True)[1]
        sName = self.cleanHtmlStr(self.cm.ph.getSearchGroups(tmp, '''data.+?['"]&p=([^=]+?)&''')[0])

        tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, '<li', '</li>')
        for item in tmp:
            sErver = self.cm.ph.getSearchGroups(item, '''onClick=['"]server_ch\((.+?)''', ignoreCase=True)[0]
            sPage = self.cm.ph.getSearchGroups(item, '''onClick=['"]server_ch.+?,['"]([^"^']+?)['"]''', ignoreCase=True)[0]
            siteUrl = self.getFullUrl(f'/plugins/server{sErver}/embed.php?url={sPage}&id={sName}')

            sts, data = self.getPage(siteUrl)
            if not sts:
                return

            url = self.getFullUrl(self.ph.search(data, self.ph.IFRAME_SRC_URI_RE)[1])

            title = (f" {E2ColoR('lightred')} [Server {sErver}]{E2ColoR('white')}{E2ColoR('yellow')} - {self.up.getHostName(url, True)}{E2ColoR('white')}")
            urlTab.append({'name': title, 'url': url, 'need_resolve': 1})
        return urlTab

    def getVideoLinks(self, videoUrl):
        printDBG(f"CartoonArbi.getVideoLinks [{videoUrl}]")

        return self.up.getVideoLinkExt(videoUrl)

    def getArticleContent(self, cItem):
        printDBG(f"CartoonArbi.getArticleContent [{cItem}]")
        otherInfo = {}

        mainUrl = cItem['url']
        if 'prev_url' in cItem:
            mainUrl = cItem['prev_url']

        sts, data = self.getPage(mainUrl)
        if not sts:
            return

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('ico_story', '>'), ('ico_download', '>'), True)[1]
        if not (desc := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('style', '>'), '</div>', False)[1])):
            desc = cItem['desc']

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('game_name_c', '>'), ('game_name_n esp_tag', '>'), True)[1]

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('esp_vis', '>'), '</div>', False)[1]):
            otherInfo['views'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('esp_time', '>'), '</div>', False)[1]):
            otherInfo['duration'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('esp_date', '>'), '</div>', False)[1]):
            otherInfo['year'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('esp_cat', '>'), '</div>', False)[1]):
            otherInfo['type'] = Info

        return [{'title': cItem['title'], 'text': desc, 'images': [{'title': '', 'url': cItem['icon']}], 'other_info': otherInfo}]

    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('handleService start')

        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        printDBG(f"handleService: |||||||||||||||||||||||||||||||||||| name[{name}], category[{category}] ")
        self.currList = []

        # MAIN MENU
        if name is None and not category:
            self.listMainMenu({'name': 'category', 'type': 'category'})
        elif any(x in category for x in ['show_movies', 'show_series']):
            self.listItems(self.currItem, 'explore_item')
        elif category == 'explore_item':
            self.exploreItems(self.currItem)
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):

    def __init__(self):
        CHostBase.__init__(self, CartoonArbi(), True, [])

    def withArticleContent(self, cItem):
        if 'prev_url' in cItem or cItem.get('category', '') == 'explore_item':
            return True
        return False
