    # -*- coding: utf-8 -*-
# Coding: BY MOHAMED_OS


from Plugins.Extensions.IPTVPlayer.compat import urllib_quote
from Plugins.Extensions.IPTVPlayer.components.ihost import (CBaseHostClass,
                                                            CHostBase)
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import \
    GetIPTVNotify
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import \
    TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import (E2ColoR, printDBG,
                                                           printExc)


def GetConfigList():
    optionList = []
    return optionList


def gettytul():
    return 'Brstej'


class Brstej(CBaseHostClass):

    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'brstej', 'cookie': 'brstej.cookie'})

        self.MAIN_URL = 'https://ser.brstej.com/'
        self.DEFAULT_ICON_URL = 'https://i.ibb.co/sj6ctLV/brstej.png'

        self.HEADER = self.cm.getDefaultHeader()
        self.AJAX_HEADER = self.HEADER
        self.AJAX_HEADER.update({'X-Requested-With': 'XMLHttpRequest'})
        self.defaultParams = {'header': self.HEADER, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}

    def getPage(self, baseUrl, addParams={}, post_data=None):
        if addParams == {}:
            addParams = dict(self.defaultParams)

        sts, data = self.cm.getPage(self.cm.ph.stdUrl(baseUrl), addParams, post_data)
        return sts, data

    def listMainMenu(self, cItem):
        printDBG("Brstej.listMainMenu")
        MAIN_CAT_TAB = [
            {'category': 'movei', 'title': _('الأفـــلام'), 'icon': self.DEFAULT_ICON_URL},
            {'category': 'serie', 'title': _('مســلـســلات'), 'icon': self.DEFAULT_ICON_URL},
            {'category': 'tvshow', 'title': _('بــرامــج'), 'icon': self.DEFAULT_ICON_URL, 'url': self.getFullUrl('/category102.php?cat=tv3-2024')},
            {'category': 'search', 'title': _('Search'), 'search_item': True},
            {'category': 'search_history', 'title': _('Search history'), }]
        self.listsTab(MAIN_CAT_TAB, cItem)

    def listCatItems(self, cItem, nextCategory):
        printDBG(f"Brstej.listCatItems cItem[{cItem}]")
        category = self.currItem.get("category", '')

        sts, data = self.getPage(f'{self.getMainUrl()}/ind6')
        if not sts:
            return

        category_mapping = {
            'movei': '> افلام <',
            'serie': '> مسلسلات برستيج <'
        }
        sStart = category_mapping.get(category, '')

        tmp = self.cm.ph.getDataBeetwenMarkers(data, sStart, ('</ul', '>'), True)[1]
        tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, ('<li', 'sub_ca'), ('</li', '>'))
        for item in tmp:
            url = self.getFullUrl(self.ph.search(item, self.ph.A_HREF_URI_RE)[1])
            title = self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(item, ('sub_ca', '>'), ('</a', '>'), False)[1])

            if not 'حلقات' in title:
                params = dict(cItem)
                params.update({'category': nextCategory, 'good_for_fav': True, 'EPG': True, 'title': title, 'url': url, 'icon': cItem['icon'], 'desc': ''})
                self.addDir(params)

    def listItems(self, cItem, nextCategory):
        printDBG(f"Brstej.listItems cItem[{cItem}]")
        page = cItem.get('page', 1)

        sts, data = self.getPage(cItem['url'])
        if not sts:
            return

        nextPage = self.cm.ph.getDataBeetwenMarkers(data, ('<ul', '>', 'pagination'), ('</ul', '>'), True)[1]
        nextPage = self.getFullUrl(self.cm.ph.getSearchGroups(self.ph.decodeHtml(nextPage), f'''href=['"]([^'^"]+?)['"][^>]*?>{page + 1}< ''')[0])

        titlesTab = []
        if not (tmp := self.cm.ph.getDataBeetwenMarkers(data, ('<ul', '>', 'pm-grid'), ('<div', '>', 'clearfix'), True)[1]):
            tmp = self.cm.ph.getDataBeetwenMarkers(data, ('<div', '>', 'col-md-12 text-center'), ('<div', '>', 'col-md-3'), True)[1]
            GetIPTVNotify().push(self.cleanHtmlStr(tmp), 5)
            self.listMainMenu({'name': 'category', 'type': 'category'})

        tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, ('<div', '>', 'thumbnail'), ('</li', '>'))
        for item in tmp:
            icon = self.getFullIconUrl(self.cm.ph.getSearchGroups(item, '''data-echo=['"]([^"^']+?)['"]''')[0])
            url = self.getFullUrl(self.cm.ph.getSearchGroups(item, '''<a href=['"]([^"^']+?)['"]''')[0])
            title = self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(item, ('ellipsis', '>'), ('</h3', '>'), False)[1])

            info = self.ph.std_title(title.split('الحلقة')[0])
            if title != '':
                title = info['title_display']
            desc = info['desc']

            if title not in titlesTab:
                titlesTab.append(title)
                params = dict(cItem)
                params.update({'category': nextCategory, 'good_for_fav': True, 'EPG': True, 'title': title, 'url': url, 'icon': self.cm.ph.stdUrl(icon), 'desc': desc})
                self.addDir(params)

        if nextPage != '':
            params = dict(cItem)
            params.update({'title': _("Next page"), 'url': nextPage, 'page': page + 1})
            self.addDir(params)

    def exploreItems(self, cItem):
        printDBG(f"Brstej.exploreItems cItem[{cItem}]")

        sts, data = self.getPage(cItem['url'])
        if not sts:
            return

        Season = self.cm.ph.getDataBeetwenNodes(data, ('<div', '>', 'SeasonsEpisodesMain'), ('<div', '>', 'clearfix'), True)[1]
        if (tmpSeason := self.cm.ph.getAllItemsBeetwenMarkers(Season, ('<div', '>', 'data-serie'), ('</div', '>'))):
            for itemS in tmpSeason:
                title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(itemS, '''data-serie=['"]([^"^']+?)['"]''')[0])
                self.addMarker({'title': f"{E2ColoR('lime')} Season", 'icon': cItem['icon'], 'desc': ''})

                tmp = self.cm.ph.getAllItemsBeetwenMarkers(itemS, '<a', ('</a', '>'))
                for item in tmp:
                    url = self.getFullUrl(self.ph.search(item, self.ph.A_HREF_URI_RE)[1])
                    title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''title=['"]([^"^']+?)['"]''')[0])

                    info = self.ph.std_title(title, with_ep=True)
                    if title != '':
                        title = info['title_display']
                    desc = info['desc']

                    params = dict(cItem)
                    params.update({'good_for_fav': True, 'EPG': True, 'title': title, 'url': url, 'icon': cItem['icon'], 'desc': desc})
                    self.addVideo(params)
        else:
            params = dict(cItem)
            params.update({'good_for_fav': True, 'EPG': True, 'title': cItem['title'], 'url': cItem['url'], 'icon': cItem['icon'], 'desc': cItem['desc']})
            self.addVideo(params)

    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG(f"Brstej.listSearchResult cItem[{cItem}], searchPattern[{searchPattern}] searchType[{searchType}]")
        url = self.getFullUrl(f'/search.php?keywords={urllib_quote(searchPattern)}')
        params = {'name': 'category', 'good_for_fav': False, 'url': url}
        self.listItems(params, 'explore_item')

    def getLinksForVideo(self, cItem):
        printDBG(f"Brstej.getLinksForVideo [{cItem}]")
        urlTab = []

        baseUrl = cItem['url'].replace("watch.php", "play.php")
        sts, data = self.getPage(baseUrl)
        if not sts:
            return

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('<div', '>', 'WatchServers'), ('</div', '>'), True)[1]
        tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, '<button', ('</button', '>'))
        for item in tmp:
            url = self.getFullUrl(self.cm.ph.getSearchGroups(item, '''data-embed-url=['"]([^"^']+?)['"]''')[0])
            if (title := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(item, ('</span', '>'), ('</button', '>'), False)[1])):
                title = (f"{cItem['title']} {E2ColoR('lightred')} [{title}]{E2ColoR('white')}{E2ColoR('yellow')} - {self.up.getHostName(url, True)}{E2ColoR('white')}")

            urlTab.append({'name': title, 'url': url, 'need_resolve': 1})

        return urlTab

    def getVideoLinks(self, videoUrl):
        printDBG(f"Brstej.getVideoLinks [{videoUrl}]")

        if self.cm.isValidUrl(videoUrl):
            return self.up.getVideoLinkExt(videoUrl)

    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('handleService start')

        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        printDBG(f"handleService: |||||||||||||||||||||||||||||||||||| name[{name}], category[{category}] ")
        self.currList = []

    # MAIN MENU
        if name is None and not category:
            self.listMainMenu({'name': 'category', 'type': 'category'})
        elif any(x in category for x in ['serie', 'movei']):
            self.listCatItems(self.currItem, 'listItems')
        elif any(x in category for x in ['listItems', 'tvshow']):
            self.listItems(self.currItem, 'explore_item')
        elif category == 'explore_item':
            self.exploreItems(self.currItem)
    # SEARCH
        elif any(x in category for x in ['search', 'search_next_page']):
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
    # HISTORIA SEARCH
        elif category == "search_history":
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):

    def __init__(self):
        CHostBase.__init__(self, Brstej(), True, [])
