# -*- coding: utf-8 -*-
# Coding: BY MOHAMED_OS

from re import compile as reCompile
from re import sub as reSub

from Plugins.Extensions.IPTVPlayer.compat import urllib_quote_plus
from Plugins.Extensions.IPTVPlayer.components.ihost import (CBaseHostClass,
                                                            CHostBase)
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import \
    TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import (E2ColoR, printDBG,
                                                           printExc)
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta


def GetConfigList():
    optionList = []
    return optionList


def gettytul():
    return 'ShoofMAX'


class ShoofMAX(CBaseHostClass):

    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'shoofmax', 'cookie': 'shoofmax.cookie'})

        self.MAIN_URL = 'https://shoofmax.com/'
        self.DEFAULT_ICON_URL = 'https://i.ibb.co/W2MrRLt/shoofmax.png'
        self.MAIN_ICON_URL = "https://shoofmax-static.b-cdn.net/v2/img/program/main/{0}-2.jpg"

        self.HEADER = self.cm.getDefaultHeader()
        self.AJAX_HEADER = self.HEADER
        self.AJAX_HEADER.update({'X-Requested-With': 'XMLHttpRequest'})
        self.defaultParams = {'header': self.HEADER, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}

    def getPage(self, baseUrl, addParams={}, post_data=None):
        if addParams == {}:
            addParams = dict(self.defaultParams)

        sts, data = self.cm.getPage(self.cm.ph.stdUrl(baseUrl), addParams, post_data)
        return sts, data

    def listMainMenu(self, cItem):
        printDBG("ShoofMAX.listMainMenu")
        MAIN_CAT_TAB = [
            {'category': 'movei', 'title': _('الأفـــلام'), 'icon': self.DEFAULT_ICON_URL, 'url': self.getFullUrl('genre/filter/فيلم/1/yop?country=&subgenre=')},
            {'category': 'serie', 'title': _('مســلـســلات'), 'icon': self.DEFAULT_ICON_URL, 'url': self.getFullUrl('genre/filter/مسلسل/1/yop?country=&subgenre=')},
            {'category': 'search', 'title': _('Search'), 'search_item': True},
            {'category': 'search_history', 'title': _('Search history'), }]
        self.listsTab(MAIN_CAT_TAB, cItem)

    def listItems(self, cItem, nextCategory):
        printDBG(f"ShoofMAX.listItems cItem[{cItem}]")
        category = self.currItem.get("category", '')
        page = cItem.get('page', 1)

        sts, data = self.getPage(cItem['url'])
        if not sts:
            return
        tmp = json_loads(data)

        parts = cItem['url'].split("/")
        parts[6] = str(page + 1)
        nextPage = self.getFullUrl("/".join(parts))

        for item in tmp:
            icon = self.getFullIconUrl(self.MAIN_ICON_URL.format(item.get('presbase', '')))
            url = self.getFullUrl(f"program/{item.get('pid', '')}{'?ep=1' if 'serie' in category else ''}")
            title = self.cleanHtmlStr(item.get('ptitle', ''))
            pTitle = self.cleanHtmlStr(item.get('presbase', ''))

            info = self.ph.std_title(title)
            if title != '':
                title = info['title_display']
            desc = info['desc']

            params = dict(cItem)
            params.update({'category': nextCategory, 'good_for_fav': True, 'EPG': True, 'title': title, 'url': url, 'icon': self.cm.ph.stdUrl(icon), 'desc': desc, 'pTitle': pTitle})
            self.addDir(params)

        if nextPage != '':
            params = dict(cItem)
            params.update({'title': _("Next page"), 'url': nextPage, 'page': page + 1})
            self.addDir(params)

    def exploreItems(self, cItem):
        printDBG(f"ShoofMAX.exploreItems cItem[{cItem}]")

        sts, data = self.getPage(cItem['url'])
        if not sts:
            return
        cItem['prev_url'] = cItem['url']

        desc = self.cleanHtmlStr(self.cm.ph.getDataBeetwenReMarkers(data, reCompile('''<[^>]+class=["']meta-section-li["'][$>][ \t\n\r\f\v]'''), reCompile('</div>'), True)[1])

        if (Episode := self.cm.ph.getDataBeetwenReMarkers(data, reCompile('</select>'), reCompile('''<[^>]+class=["']episode-control-icon ["']'''), True)[1]):
            sEpisodes = int(self.ph.search(Episode, reCompile('(\d+)'))[0])
            mainUrl = f"{cItem['url'].split('?ep=')[0]}?ep="
            sEpiList = [f"{mainUrl}{episode_number}" for episode_number in range(1, int(sEpisodes) + 1)]
            for item in sEpiList:

                url = self.getFullUrl(item)
                title = f"الحلقة {item.split('?ep=')[1]}"

                info = self.ph.std_title(title, with_ep=True)
                if title != '':
                    title = info['title_display']
                otherInfo = f"{info['desc']}\n{desc}"

                params = dict(cItem)
                params.update({'good_for_fav': True, 'EPG': True, 'title': title, 'url': url, 'icon': cItem['icon'], 'desc': otherInfo, 'pTitle': cItem['pTitle']})
                self.addVideo(params)
        else:
            params = dict(cItem)
            params.update({'good_for_fav': True, 'EPG': True, 'title': cItem['title'], 'url': cItem['url'], 'icon': cItem['icon'], 'desc': desc, 'pTitle': cItem['pTitle']})
            self.addVideo(params)

    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG(f"ShoofMAX.listSearchResult cItem[{cItem}], searchPattern[{searchPattern}] searchType[{searchType}]")
        url = self.getFullUrl(f'/search?q={urllib_quote_plus(searchPattern)}')
        params = {'name': 'category', 'good_for_fav': False, 'url': url}
        self.showSearchResults(params, 'explore_item')

    def showSearchResults(self, cItem, nextCategory):
        printDBG(f"ShoofMAX.showSearchResults [{cItem}]")

        sts, data = self.getPage(cItem['url'])
        if not sts:
            return
        cItem['prev_url'] = cItem['url']

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('<div', '>', 'general-body'), ('<div', '>', 'search-bottom-padding'), True)[1]
        tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, ('<a', '>'), ('</a', '>'))
        for item in tmp:
            icon = self.ph.search(item, reCompile('url\(([^"^\)]+?\.(:?jpe?g|png)(:?\?[^"^\)]+?)?)\)'))[0]
            url = self.getFullUrl(self.ph.search(item, self.ph.A_HREF_URI_RE)[1])
            title = self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(item, ('<span', '>'), ('</div', '>'), False)[1])
            pTitle = reSub(r"-?\d+\.jpg", "", icon.split("/")[-1])

            info = self.ph.std_title(title, with_ep=True)
            if title != '':
                title = title = info['title_display']
            desc = info['desc']

            params = dict(cItem)
            params.update({'category': nextCategory, 'good_for_fav': True, 'EPG': True, 'title': title, 'url': url, 'icon': icon, 'desc': desc, 'pTitle': pTitle})
            self.addDir(params)

    def getLinksForVideo(self, cItem):
        printDBG(f"ShoofMAX.getLinksForVideo [{cItem}]")
        urlTab = []

        baseUrl = cItem['url']
        sts, data = self.getPage(baseUrl)
        if not sts:
            return

        mainUrl = self.getFullUrl(self.cm.ph.getSearchGroups(data, '''origin_link = ['"]([^"^']+?)['"]''')[0])

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('var', 'getHlsBwEstimate'), ('startVideo', 'function'), True)[1]
        tmp = reCompile('''rendition = ['"]([^"^']+?)['"]''').findall(tmp)
        for item in tmp:
            if '?ep=' in baseUrl:
                sEp = f'{baseUrl.split("?ep=")[1]}'
                sHosterUrl = f'{mainUrl}/{cItem['pTitle']}/ep{sEp}/{item}/index.m3u8'
            else:
                sHosterUrl = f'{mainUrl}/{cItem['pTitle']}/{item}/index.m3u8'

            if sHosterUrl != '':
                hlsUrl = strwithmeta(sHosterUrl, {'User-Agent': self.defaultParams['header']['User-Agent'], 'Referer': baseUrl})
                title = (f"Quality: {E2ColoR('lightred')}{item}{E2ColoR('white')}")

                urlTab.append({'name': title, 'url': hlsUrl, 'need_resolve': 0})

        return urlTab

    def getVideoLinks(self, videoUrl):
        printDBG(f"ShoofMAX.getVideoLinks [{videoUrl}]")

        if self.cm.isValidUrl(videoUrl):
            return self.up.getVideoLinkExt(videoUrl)

    def getArticleContent(self, cItem):
        printDBG(f"ShoofMAX.getArticleContent [{cItem}]")
        otherInfo = {}

        mainUrl = cItem['url']
        if 'prev_url' in cItem:
            mainUrl = cItem['prev_url']

        sts, data = self.getPage(mainUrl)
        if not sts:
            return

        descData = self.cm.ph.getDataBeetwenMarkers(data, ('<div', '>', 'about-program'), ('<div', '>', 'container'), True)[1]
        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(descData, ('سنة انتاج', '</b>'), ('</div', '>'), False)[1]):
            otherInfo['year'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(descData, ('دولة الانتاج', '</b>'), ('</div', '>'), False)[1]):
            otherInfo['country'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(descData, ('الفئة', '</b>'), ('</div', '>'), False)[1]):
            otherInfo['genre'] = Info

        if not (desc := self.cleanHtmlStr(self.cm.ph.getDataBeetwenReMarkers(descData, reCompile('''<[^>]+class=["']meta-section-li["'][$>][ \t\n\r\f\v]'''), reCompile('</div>'), True)[1])):
            desc = cItem['desc']

        tmpTab = []
        tmp = self.cm.ph.getDataBeetwenNodes(descData, ('بطولة', '>'), ('<div', '>', 'meta-show-more'), False)[1]
        tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, '</b>', '</div>')
        for t in tmp:
            tmpTab.append(self.cleanHtmlStr(t))
        if len(tmpTab):
            otherInfo['actors'] = ', '.join(tmpTab)

        return [{'title': cItem['title'], 'text': desc, 'images': [{'title': '', 'url': cItem['icon']}], 'other_info': otherInfo}]

    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('handleService start')

        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        printDBG(f"handleService: |||||||||||||||||||||||||||||||||||| name[{name}], category[{category}] ")
        self.currList = []

    # MAIN MENU
        if name == None and category == '':
            self.listMainMenu({'name': 'category', 'type': 'category'})
        elif category in ['movei', 'serie']:
            self.listItems(self.currItem, 'explore_item')
        elif category == 'explore_item':
            self.exploreItems(self.currItem)
    # SEARCH
        elif category in ["search", "search_next_page"]:
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
    # HISTORIA SEARCH
        elif category == "search_history":
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):

    def __init__(self):
        CHostBase.__init__(self, ShoofMAX(), True, [])

    def withArticleContent(self, cItem):
        if 'prev_url' in cItem or cItem.get('category', '') == 'explore_item':
            return True
        return False
