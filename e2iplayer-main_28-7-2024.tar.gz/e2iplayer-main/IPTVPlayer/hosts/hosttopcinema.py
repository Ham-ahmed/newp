# -*- coding: utf-8 -*-
# Coding: BY MOHAMED_OS

from re import compile as reCompile

from Plugins.Extensions.IPTVPlayer.compat import urljoin, urllib_quote_plus
from Plugins.Extensions.IPTVPlayer.components.ihost import (CBaseHostClass,
                                                            CHostBase)
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import \
    TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import (E2ColoR, printDBG,
                                                           printExc)
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta


def GetConfigList():
    optionList = []
    return optionList


def gettytul():
    return 'TopCinema'


class TopCinema(CBaseHostClass):

    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'topcinema', 'cookie': 'topcinema.cookie'})

        self.MAIN_URL = 'https://web3.topcinema.top/'
        self.DEFAULT_ICON_URL = 'https://i.ibb.co/MG0J6YQ/topcinema.png'

        self.HEADER = self.cm.getDefaultHeader()
        self.AJAX_HEADER = self.HEADER
        self.AJAX_HEADER.update({'X-Requested-With': 'XMLHttpRequest', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Dest': 'empty', 'Sec-Fetch-Site': 'same-origin'})
        self.defaultParams = {'header': self.HEADER, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}

    def getPage(self, baseUrl, addParams={}, post_data=None):
        if addParams == {}:
            addParams = dict(self.defaultParams)

        sts, data = self.cm.getPage(self.cm.ph.stdUrl(baseUrl), addParams, post_data)
        return sts, data

    def listMainMenu(self, cItem):
        printDBG("TopCinema.listMainMenu")
        MAIN_CAT_TAB = [
            {'category': 'home', 'title': _(f"{E2ColoR('lime')} المضاف حديثا"), 'icon': self.DEFAULT_ICON_URL, 'url': self.getFullUrl('/recent/')},
            {'category': 'movei', 'title': _('الأفـــلام'), 'icon': self.DEFAULT_ICON_URL},
            {'category': 'serie', 'title': _('مســلـســلات'), 'icon': self.DEFAULT_ICON_URL},
            {'category': 'asia', 'title': _('أســـيــويــة'), 'icon': self.DEFAULT_ICON_URL},
            {'category': 'anime', 'title': _('أنـــــمــي'), 'icon': self.DEFAULT_ICON_URL},
            {'category': 'search', 'title': _('Search'), 'search_item': True},
            {'category': 'search_history', 'title': _('Search history'), }]
        self.listsTab(MAIN_CAT_TAB, cItem)

    def listCatItems(self, cItem, nextCategory):
        printDBG(f"TopCinema.listCatItems cItem[{cItem}]")
        category = self.currItem.get("category", '')

        sts, data = self.getPage(self.getMainUrl())
        if not sts:
            return

        category_mapping = {
            'movei': 'menu-item-73',
            'serie': 'menu-item-112',
            'asia': 'menu-item-152',
            'anime': 'menu-item-157',
        }
        sStart = category_mapping.get(category, '')

        tmp = self.cm.ph.getDataBeetwenReMarkers(data, reCompile(f'''<[^>]+class=["'].+?{sStart}["'][$>]'''), reCompile('</ul>'), True)[1]
        tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, ('<li', 'menu-item'), ('</li', '>'))
        for item in tmp:
            url = self.getFullUrl(self.ph.search(item, self.ph.A_HREF_URI_RE)[1])
            title = self.cleanHtmlStr(item)

            params = dict(cItem)
            params.update({'category': nextCategory, 'good_for_fav': True, 'EPG': True, 'title': title, 'url': url, 'icon': cItem['icon'], 'desc': ''})
            self.addDir(params)

    def listItems(self, cItem, nextCategory):
        printDBG(f"TopCinema.listItems cItem[{cItem}]")
        page = cItem.get('page', 1)

        sts, data = self.getPage(cItem['url'])
        if not sts:
            return

        nextPage = self.cm.ph.getDataBeetwenMarkers(data, ('<div', '>', 'paginate'), ('</ul>', '</div>'), True)[1]
        nextPage = self.getFullUrl(self.cm.ph.getSearchGroups(nextPage, f'''href=['"]([^'^"]+?)['"][^>]*?>{page + 1}<''')[0])

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('<ul', '>', 'Posts--List SixInRow'), ('</script', '>'), True)[1]
        tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, ('<div', '>', 'Small--Box'), ('</a>', '</div>'))
        for item in tmp:
            icon = self.getFullIconUrl(self.cm.ph.getSearchGroups(item, '''data-src=['"]([^"^']+?)['"]''')[0])
            url = self.getFullUrl(self.ph.search(item, self.ph.A_HREF_URI_RE)[1])
            title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''alt=['"]([^"^']+?)['"]''')[0]).strip()
            desc = self.ph.extract_desc(item, [('quality', '''ribbon['"]>([^>]+?)[$<]'''), ('rating', '''fa-star['"].+?>([^>]+?)[$<]''')])

            info = self.ph.std_title(title, desc=desc, with_ep=True)
            if title != '':
                title = info['title_display']
            desc = info['desc']

            category = nextCategory
            if any(x in url for x in ['/series/', '/assemblies/']):
                url = urljoin(url, 'list/')
                category = 'listSeasons'

            params = dict(cItem)
            params.update({'category': category, 'good_for_fav': True, 'EPG': True, 'title': title, 'url': url, 'icon': self.cm.ph.stdUrl(icon), 'desc': desc})
            self.addDir(params)

        if nextPage != '':
            params = dict(cItem)
            params.update({'title': _("Next page"), 'url': nextPage, 'page': page + 1})
            self.addDir(params)

    def showSeasons(self, cItem, nextCategory):
        printDBG(f"TopCinema.showSeasons cItem[{cItem}]")

        sts, data = self.getPage(cItem['url'])
        if not sts:
            return

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('<div', '>', 'TitleBox Small'), ('</script', '>'), True)[1]
        tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, '<a', ('</a', '>'))
        for item in tmp:
            title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''alt=['"]([^"^']+?)['"]''')[0]).strip()
            url = self.getFullUrl(self.ph.search(item, self.ph.A_HREF_URI_RE)[1])

            info = self.ph.std_title(title, with_ep=True)
            if title != '':
                title = info['title_display']
            desc = info['desc']

            params = dict(cItem)
            params.update({'category': nextCategory, 'good_for_fav': True, 'EPG': True, 'title': title, 'url': urljoin(url, 'list/'), 'icon': cItem['icon'], 'desc': desc})
            self.addDir(params)

    def exploreItems(self, cItem):
        printDBG(f"TopCinema.exploreItems cItem[{cItem}]")

        sts, data = self.getPage(cItem['url'])
        if not sts:
            return
        cItem['prev_url'] = cItem['url']

        desc = self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(data, ('<div', '>', 'story'), ('</p', '>'), False)[1])

        if '/series/' in cItem['url']:
            tmp = self.cm.ph.getDataBeetwenMarkers(data, ('<ul', '>', 'Posts--List SixInRow'), ('</script', '>'), True)[1]
            tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, ('<div', '>', 'Small--Box'), ('</a>', '</div>'))
            for item in tmp:
                url = self.getFullUrl(self.ph.search(item, self.ph.A_HREF_URI_RE)[1])
                title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''alt=['"]([^"^']+?)['"]''')[0]).strip()

                info = self.ph.std_title(title, with_ep=True)
                if title != '':
                    title = info['title_display']
                otherInfo = f"{info['desc']}\n{desc}"

                params = dict(cItem)
                params.update({'good_for_fav': True, 'EPG': True, 'title': title, 'url': url, 'icon': cItem['icon'], 'desc': otherInfo})
                self.addVideo(params)
        else:
            params = dict(cItem)
            params.update({'good_for_fav': True, 'EPG': True, 'title': cItem['title'], 'url': cItem['url'], 'icon': cItem['icon'], 'desc': desc})
            self.addVideo(params)

    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG(f"TopCinema.listSearchResult cItem[{cItem}], searchPattern[{searchPattern}] searchType[{searchType}]")
        url = self.getFullUrl(f'/?s={urllib_quote_plus(searchPattern)}&type={searchType}')
        params = {'name': 'category', 'good_for_fav': False, 'url': url}
        self.listItems(params, 'explore_item')

    def getLinksForVideo(self, cItem):
        printDBG(f"TopCinema.getLinksForVideo [{cItem}]")
        urlTab = []

        baseUrl = urljoin(cItem['url'].replace('list/', ''), 'watch/')
        sts, data = self.getPage(baseUrl)
        if not sts:
            return

        ajaxURL = self.getFullUrl(self.cm.ph.getSearchGroups(data, '''MyAjaxURL = ['"]([^"^']+?)['"]''')[0])

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('<h2', '>', 'watch--servers-title'), ('</ul', '>'), True)[1]
        tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, '<li', ('</li', '>'))
        for item in tmp:
            Sid = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''data-id=['"]([^"^']+?)['"]''')[0])
            Serv = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''data-server=['"]([^"^']+?)['"]''')[0])
            title = self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(item, ('<span', '>'), ('</span', '>'), False)[1])

            post_data = {'id': Sid, 'i': Serv}

            params = dict(self.defaultParams)
            params['header'] = dict(self.AJAX_HEADER)
            params['header']['Referer'] = self.cm.meta['url']
            params['header']['Origin'] = self.getMainUrl()
            params['header']['Host'] = self.up.getDomain(baseUrl)

            sts, data = self.getPage(urljoin(ajaxURL, 'Single/Server.php'), params, post_data)
            if not sts:
                return

            url = self.getFullUrl(self.ph.search(data, self.ph.IFRAME_SRC_URI_RE)[1])

            if title != '':
                title = (f"{cItem['title']} {E2ColoR('lightred')} [{title}]{E2ColoR('white')}{E2ColoR('yellow')} - {self.up.getHostName(url, True)}{E2ColoR('white')}")
            urlTab.append({'name': title, 'url': strwithmeta(url, {'Referer': self.getMainUrl()}), 'need_resolve': 1})
        return urlTab

    def getVideoLinks(self, videoUrl):
        printDBG(f"TopCinema.getVideoLinks [{videoUrl}]")

        return self.up.getVideoLinkExt(videoUrl)

    def getArticleContent(self, cItem):
        printDBG(f"TopCinema.getArticleContent [{cItem}]")
        otherInfo = {}

        mainUrl = cItem['url']
        if 'prev_url' in cItem:
            mainUrl = cItem['prev_url']

        sts, data = self.getPage(mainUrl)
        if not sts:
            return

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('<div', '>', 'infoAndWatch'), ('<div', '>', 'BTNSDownWatch'), True)[1]

        if not (desc := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('<div', '>', 'story'), ('</p', '>'), False)[1])):
            desc = cItem['desc']

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(data, ('<div', '>', 'imdbR'), ('</span', '>'), False)[1]):
            otherInfo['imdb_rating'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('category', '>'), ('</li', '>'), False)[1]):
            otherInfo['category'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('genre', '>'), ('</li', '>'), False)[1]):
            otherInfo['genre'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('fa-clock', '<strong>'), ('</strong', '>'), False)[1]):
            otherInfo['duration'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('Quality', '>'), ('</a', '>'), False)[1]):
            otherInfo['quality'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('release-year', '>'), ('</a', '>'), False)[1]):
            otherInfo['year'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(tmp, ('/language', '>'), ('</a', '>'), False)[1]):
            otherInfo['language'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(tmp, ('nation', '>'), ('</a', '>'), False)[1]):
            otherInfo['country'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(tmp, ('director', '>'), ('</li', '>'), False)[1]):
            otherInfo['directors'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(tmp, ('escritor', '>'), ('</li', '>'), False)[1]):
            otherInfo['writers'] = Info

        if Info := self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(tmp, ('actor', '>'), ('</li', '>'), False)[1]):
            otherInfo['actors'] = Info

        return [{'title': cItem['title'], 'text': desc, 'images': [{'title': '', 'url': cItem['icon']}], 'other_info': otherInfo}]

    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('handleService start')

        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        printDBG(f"handleService: |||||||||||||||||||||||||||||||||||| name[{name}], category[{category}] ")
        self.currList = []

        # MAIN MENU
        if name is None and not category:
            self.listMainMenu({'name': 'category', 'type': 'category'})
        elif any(x in category for x in ['movei', 'serie', 'asia', 'anime']):
            self.listCatItems(self.currItem, 'listItems')
        elif any(x in category for x in ['listItems', 'home']):
            self.listItems(self.currItem, 'explore_item')
        elif category == 'listSeasons':
            self.showSeasons(self.currItem, 'explore_item')
        elif category == 'explore_item':
            self.exploreItems(self.currItem)
    # SEARCH
        elif any(x in category for x in ['search', 'search_next_page']):
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
    # HISTORIA SEARCH
        elif category == "search_history":
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):

    def __init__(self):
        CHostBase.__init__(self, TopCinema(), True, [])

    def getSearchTypes(self):
        searchTypesOptions = []
        searchTypesOptions.append(("Movies", "movies"))
        searchTypesOptions.append(("Tv Series", "series"))
        return searchTypesOptions

    def withArticleContent(self, cItem):
        if 'prev_url' in cItem or cItem.get('category', '') == 'explore_item':
            return True
        return False
