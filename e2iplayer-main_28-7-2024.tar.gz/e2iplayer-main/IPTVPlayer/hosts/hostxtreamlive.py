# -*- coding: utf-8 -*-
# Coding: BY MOHAMED_OS

from base64 import b64decode
from datetime import datetime

from Components.config import config
from Plugins.Extensions.IPTVPlayer.compat import e2Json_dump, e2Json_loads
from Plugins.Extensions.IPTVPlayer.components.ihost import (CBaseHostClass,
                                                            CHostBase)
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import \
    GetIPTVNotify
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import \
    TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import (E2ColoR,
                                                           fileReadLine,
                                                           printDBG, printExc)
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
from Tools.Directories import SCOPE_CONFIG, fileExists, resolveFilename

CheckIPAudio = config.plugins.iptvplayer.ipaudio.value
XtreamPath = config.plugins.iptvplayer.xtreamPath.value


def gettytul():
    return f"Xtream {E2ColoR('cyan')}LIVE{E2ColoR('white')}"


class XtreamLive(CBaseHostClass):

    def __init__(self):
        CBaseHostClass.__init__(self, {'cookie': 'xtreamlive.cookie'})

        self.MAIN_URL = '{0}/player_api.php?username={1}&password={2}&action={3}'
        self.DEFAULT_ICON_URL = 'https://i.ibb.co/LYGhL5v/xtream.png'

        self.defaultParams = {'User-Agent': self.cm.getDefaultUserAgent('mobile'), 'X-Requested-With': 'com.sportstv20.app'}

    def listMainMenu(self, cItem):
        printDBG(f"XtreamLive.listMainMenu cItem[{cItem}]")
        multi_tab = self.cm.getXtreamConf()
        if len(multi_tab) == 0:
            self.addMarker({'title': 'Please configure xstream first', 'icon': self.DEFAULT_ICON_URL, 'desc': f'Please configure xstream first, (add user, pass, host in E2Iplayer params or add your config file in {XtreamPath})'})
        elif len(multi_tab) == 1:
            params = dict(cItem)
            params.update({'icon': self.DEFAULT_ICON_URL, 'xuser': multi_tab[0][2], 'xpass': multi_tab[0][3], 'xhost': multi_tab[0][1]})
            self.listItems(params)
        else:
            for item in multi_tab:
                Url = f'{item[1]}/player_api.php?username={item[2]}&password={item[3]}'

                sts, data = self.cm.getPageRequest(Url, self.defaultParams)
                if not sts:
                    continue
                user_info = data.get("user_info", {})

                expires = datetime.fromtimestamp(int(user_info.get("exp_date"))).strftime("%d-%m-%Y  %H:%M") if user_info.get("exp_date") else "Null"
                if user_info.get("status", "") == 'Active':
                    if item[0].startswith('http'):
                        title = f"{self.up.getDomain(item[1], True).split(':')[0]} | {E2ColoR('lime')}Expired{E2ColoR('white')}: {E2ColoR('cyan')}{expires}"
                    else:
                        title = f"{item[0]} | {E2ColoR('lime')}Expired{E2ColoR('white')}: {E2ColoR('cyan')}{expires}"
                    params = dict(cItem)
                    params.update({'category': 'listCatItems', 'title': title, 'icon': self.DEFAULT_ICON_URL, 'xuser': item[2], 'xpass': item[3], 'xhost': item[1]})
                    self.addDir(params)

    def listCatItems(self, cItem):
        printDBG(f"XtreamLive.listCatItems cItem[{cItem}]")

        Url = self.MAIN_URL.format(cItem['xhost'], cItem['xuser'], cItem['xpass'], "get_live_categories")

        sts, data = self.cm.getPageRequest(Url, self.defaultParams)
        if not sts:
            return

        try:
            params = dict(cItem)
            params.update({'category': 'listItems', 'title': 'All', 'icon': cItem['icon'], 'category_id': '', 'xuser': cItem['xuser'], 'xpass': cItem['xpass'], 'xhost': cItem['xhost']})
            self.addDir(params)
            for item in data:
                params = dict(cItem)
                params.update({'good_for_fav': True, 'EPG': True, 'category': 'listItems', 'title': item['category_name'].strip(), 'icon': cItem['icon'], 'category_id': item['category_id'], 'xuser': cItem['xuser'], 'xpass': cItem['xpass'], 'xhost': cItem['xhost']})
                self.addDir(params)
        except Exception:
            printExc('Cannot parse received data !')

    def listItems(self, cItem):
        printDBG(f"XtreamLive.listItems cItem[{cItem}]")

        Url = self.MAIN_URL.format(cItem['xhost'], cItem['xuser'], cItem['xpass'], "get_live_categories")

        sts, data = self.cm.getPageRequest(Url, self.defaultParams)
        if not sts:
            return

        params = dict(cItem)
        params.update({'category': 'listItems', 'title': 'All', 'icon': cItem['icon'], 'category_id': '', 'xuser': cItem['xuser'], 'xpass': cItem['xpass'], 'xhost': cItem['xhost']})
        self.addDir(params)
        for item in data:
            params = dict(cItem)
            params.update({'category': 'listItems', 'title': item['category_name'].strip(), 'icon': cItem['icon'], 'category_id': item['category_id'], 'xuser': cItem['xuser'], 'xpass': cItem['xpass'], 'xhost': cItem['xhost']})
            self.addDir(params)

    def exploreItems(self, cItem):
        printDBG(f"XtreamLive.exploreItems cItem[{cItem}]")

        status = False
        for FileName in ['ipaudio.json', 'IPAudioPro.json', 'ipaudioplus_user_list.json', 'iptosat.json']:
            FileExists = fileExists(resolveFilename(SCOPE_CONFIG, FileName))
            if all([FileExists, CheckIPAudio]):
                status = True
                break

        Url = self.MAIN_URL.format(cItem['xhost'], cItem['xuser'], cItem['xpass'], f"get_live_streams&category_id={str(cItem['category_id'])}")
        sts, data = self.cm.getPageRequest(Url, self.defaultParams)
        if not sts:
            return

        for item in data:
            tmpUrl = f"{cItem['xhost']}/live/{cItem['xuser']}/{cItem['xpass']}/{str(item['stream_id'])}.ts"

            stream_icon = item.get("stream_icon", cItem['icon'])

            if '---' in item['name']:
                self.addMarker({'title': f"{E2ColoR('lime')}{item['name']}", 'icon': cItem['icon']})
            elif '***' in item['name']:
                self.addMarker({'title': f"{E2ColoR('yellow')}{item['name']}", 'icon': cItem['icon']})

            if status:
                params = dict(cItem)
                params.update({'category': 'listOptions', 'url': tmpUrl, 'title': item['name'], 'icon': stream_icon, 'xuser': cItem['xuser'], 'xpass': cItem['xpass'], 'xhost': cItem['xhost'], 'stream_id': item['stream_id']})
                self.addDir(params)
            else:
                params = dict(cItem)
                params.update({'good_for_fav': True, 'EPG': True, 'url': tmpUrl, 'title': item['name'], 'icon': stream_icon, 'xuser': cItem['xuser'], 'xpass': cItem['xpass'], 'xhost': cItem['xhost'], 'stream_id': item['stream_id']})
                self.addVideo(params)

    def ShowOptions(self, cItem):
        printDBG(f"XtreamLive.ShowOptions cItem[{cItem}]")
        params = dict(cItem)
        params.update({'good_for_fav': True, 'EPG': True, 'url': cItem['url'], 'title': cItem['title'], 'icon': cItem['icon'], 'xuser': cItem['xuser'], 'xpass': cItem['xpass'], 'xhost': cItem['xhost'], 'stream_id': cItem['stream_id']})
        self.addVideo(params)

        Paths = {'ipaudio': 'ipaudio.json', 'ipaudiopro': 'IPAudioPro.json', 'ipaudioplus': 'ipaudioplus_user_list.json', 'iptosat': 'iptosat.json'}
        for category, defaultPaths in Paths.items():
            if fileExists(resolveFilename(SCOPE_CONFIG, defaultPaths)):
                params = dict(cItem)
                params.update({'category': category, 'url': cItem['url'], 'title': f'Add to {category.capitalize()}', 'titre': cItem['title'], 'icon': cItem['icon']})
                self.addDir(params)

    def addtoipaudio(self, cItem):
        printDBG(f"XtreamLive.addtoipaudio cItem[{cItem}]")

        try:
            params = {"channel": cItem['titre'], "url": cItem['url']}
            data = fileReadLine(resolveFilename(SCOPE_CONFIG, 'ipaudio.json'))
            playlist = e2Json_loads(data)
            playlist['playlist'].append(params)
            with open(resolveFilename(SCOPE_CONFIG, 'ipaudio.json'), 'w') as f:
                e2Json_dump(playlist, f, indent=4)

            GetIPTVNotify().push(f"#{cItem['titre']}# Successfully added", 'info', 5)
            self.exploreItems(self.currItem)
        except Exception:
            GetIPTVNotify().push(f"#{cItem['titre']}# Not added (Error)", 'error', 5)
            self.exploreItems(self.currItem)

    def addtoipaudiopro(self, cItem):
        printDBG(f"XtreamLive.addtoipaudiopro cItem[{cItem}]")

        try:
            params = {"name": cItem['titre'], "display_name": cItem['titre'], "url": cItem['url']}
            data = fileReadLine(resolveFilename(SCOPE_CONFIG, 'IPAudioPro.json'))
            streams = e2Json_loads(data)
            streams['Playlist']['streams'].append(params)
            with open(resolveFilename(SCOPE_CONFIG, 'IPAudioPro.json'), 'w') as f:
                e2Json_dump(streams, f, indent=4)

            GetIPTVNotify().push(f"#{cItem['titre']}# Successfully added", 'info', 5)
            self.exploreItems(self.currItem)
        except Exception:
            GetIPTVNotify().push(f"#{cItem['titre']}# Not added (Error)", 'error', 5)
            self.exploreItems(self.currItem)

    def addtoipaudioplus(self, cItem):
        printDBG(f"XtreamLive.addtoipaudioplus cItem[{cItem}]")

        try:
            params = {"Name": cItem['titre'], "Url": cItem['url']}
            data = fileReadLine(resolveFilename(SCOPE_CONFIG, 'ipaudioplus_user_list.json'))
            playlist = e2Json_loads(data)
            params.update({"Id": str(int(playlist['User List']["channels"][-1]['Id']) + 1)})
            playlist['User List']["channels"].append(params)
            with open(resolveFilename(SCOPE_CONFIG, 'ipaudioplus_user_list.json'), 'w') as f:
                e2Json_dump(playlist, f, indent=4)

            GetIPTVNotify().push(f"#{cItem['titre']}# Successfully added", 'info', 5)
            self.exploreItems(self.currItem)
        except Exception:
            GetIPTVNotify().push(f"#{cItem['titre']}# Not added (Error)", 'error', 5)
            self.exploreItems(self.currItem)

    def addtoiptosat(self, cItem):
        printDBG(f"XtreamLive.addtoiptosat cItem[{cItem}]")

        try:
            params = {"channel": cItem['titre'], "url": cItem['url']}
            data = fileReadLine(resolveFilename(SCOPE_CONFIG, 'iptosat.json'))
            playlist = e2Json_loads(data)
            playlist['playlist'].append(params)
            with open(resolveFilename(SCOPE_CONFIG, 'iptosat.json'), 'w') as f:
                e2Json_dump(playlist, f, indent=4)

            GetIPTVNotify().push(f"#{cItem['titre']}# Successfully added", 'info', 5)
            self.exploreItems(self.currItem)
        except Exception:
            GetIPTVNotify().push(f"#{cItem['titre']}# Not added (Error)", 'error', 5)
            self.exploreItems(self.currItem)

    def getLinksForVideo(self, cItem):
        printDBG(f"XtreamLive.getLinksForVideo [{cItem}]")
        urlTab = []

        urlTab.append({'name': '', 'url': strwithmeta(cItem['url'], {'User-Agent': self.defaultParams['User-Agent']}), 'need_resolve': 0})

        return urlTab

    def getVideoLinks(self, videoUrl):
        printDBG(f"XtreamLive.getVideoLinks [{videoUrl}]")

        if self.cm.isValidUrl(videoUrl):
            return self.up.getVideoLinkExt(videoUrl)

    def getArticleContent(self, cItem):
        printDBG(f"XtreamLive.getArticleContent [{cItem}]")
        otherInfo = {}

        Url = self.MAIN_URL.format(cItem['xhost'], cItem['xuser'], cItem['xpass'], f"get_short_epg&stream_id={cItem['stream_id']}")

        sts, data = self.cm.getPageRequest(Url, self.defaultParams)
        if not sts:
            return

        try:
            for item in data['epg_listings']:
                time_star = item['start'].split(' ')[1]
                time_end = item['end'].split(' ')[1]
                time1, time2, x1 = time_star.split(':')
                time_1, time_2, x1 = time_end.split(':')
                start_ = f"{E2ColoR('lime')}[{time1}:{time2}-{time_1}:{time_2}]{E2ColoR('white')}"
                title = b64decode(item['title'])
                descr = b64decode(item['description'])
                desc = f'{desc}{start_} | {title} | {descr}\n'

            return [{'title': cItem['title'], 'text': desc, 'images': [{'title': '', 'url': cItem['icon']}], 'other_info': otherInfo}]
        except Exception:
            GetIPTVNotify().push('Info not available ...!', 'error', 5)

    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('handleService start')

        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        printDBG(f"handleService: |||||||||||||||||||||||||||||||||||| name[{name}], category[{category}] ")
        self.currList = []

    # MAIN MENU
        if name == None and category == '':
            self.listMainMenu({'name': 'category', 'type': 'category'})
        elif category == 'listCatItems':
            self.listCatItems(self.currItem)
        elif category == 'listOptions':
            self.ShowOptions(self.currItem)
        elif category == 'ipaudio':
            self.addtoipaudio(self.currItem)
        elif category == 'ipaudiopro':
            self.addtoipaudiopro(self.currItem)
        elif category == 'ipaudioplus':
            self.addtoipaudioplus(self.currItem)
        elif category == 'iptosat':
            self.addtoiptosat(self.currItem)
        elif category == 'listItems':
            self.exploreItems(self.currItem)
    # SEARCH
        elif category in ["search", "search_next_page"]:
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
    # HISTORIA SEARCH
        elif category == "search_history":
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):

    def __init__(self):
        CHostBase.__init__(self, XtreamLive(), True, [])

    def withArticleContent(self, cItem):
        if cItem['type'] != 'video' and cItem['category'] != 'exploreItems':
            return False
        return True
