# -*- coding: utf-8 -*-
# Vstream https://github.com/Kodi-vStream/venom-xbmc-addons
from Components.config import config, configfile
from Plugins.Extensions.IPTVPlayer.compat import e2Json_loads
from Plugins.Extensions.IPTVPlayer.libs.matrix.hosters.hoster import iHoster
from Plugins.Extensions.IPTVPlayer.libs.matrix.lib.comaddon import (VSlog,
                                                                    dialog)
from Plugins.Extensions.IPTVPlayer.libs.matrix.lib.handler.requestHandler import \
    cRequestHandler

URL_HOST = "https://debrid-link.fr"


class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'debrid_link', 'Debrid Link', 'violet')

    def _getMediaLinkForGuest(self):
        VSlog(self._url)
        token_debrid_link = f"Bearer {config.plugins.iptvplayer.debridlink_token.value}"

        oRequestHandler = cRequestHandler(f'{URL_HOST}/api/downloader/add')
        oRequestHandler.setRequestType(1)
        oRequestHandler.addHeaderEntry('Accept', 'application/json')
        oRequestHandler.addHeaderEntry('Authorization', token_debrid_link)
        oRequestHandler.addHeaderEntry('Content-Type', "application/x-www-form-urlencoded")
        oRequestHandler.addParameters("link", self._url)
        text = e2Json_loads(oRequestHandler.request())

        if text["result"] == "KO":
            if text["ERR"] == 'badToken':
                new_token = renewToken()

                oRequestHandler = cRequestHandler(f'{URL_HOST}/api/downloader/add')
                oRequestHandler.setRequestType(1)
                oRequestHandler.addHeaderEntry('Accept', 'application/json')
                oRequestHandler.addHeaderEntry('Authorization', new_token)
                oRequestHandler.addHeaderEntry('Content-Type', "application/x-www-form-urlencoded")
                oRequestHandler.addParameters("link", self._url)
                text = e2Json_loads(oRequestHandler.request())

        api_call = text["value"]["downloadLink"]

        if text:
            return True, api_call

        return False, False


def renewToken():
    if not (refreshTok := config.plugins.iptvplayer.debridlink_tokenrefresh.value):
        oRequestHandler = cRequestHandler(f"{URL_HOST}/api/oauth/device/code")
        oRequestHandler.setRequestType(1)
        oRequestHandler.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded')
        oRequestHandler.addParameters('client_id', config.plugins.iptvplayer.debridlink_ID.value)
        r = e2Json_loads(oRequestHandler.request())

        dialog().VSok(f'Allez sur la page : https://debrid-link.fr/device\n et rentrer le code {r["user_code"]} pour autorisez la connection')

        oRequestHandler = cRequestHandler(f"{URL_HOST}/api/oauth/token")
        oRequestHandler.setRequestType(1)
        oRequestHandler.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded')
        oRequestHandler.addParameters('client_id', config.plugins.iptvplayer.debridlink_ID.value)
        oRequestHandler.addParameters("code", r["device_code"])
        oRequestHandler.addParameters("grant_type", "http://oauth.net/grant_type/device/1.0")
        r = e2Json_loads(oRequestHandler.request())

        config.plugins.iptvplayer.debridlink_tokenrefresh.setValue(r["refresh_token"])
        config.plugins.iptvplayer.debridlink_tokenrefresh.save()

        config.plugins.iptvplayer.debridlink_token.setValue(r["access_token"])
        config.plugins.iptvplayer.debridlink_token.save()

        configfile.save()
        return r["access_token"]

    else:
        oRequestHandler = cRequestHandler(f"{URL_HOST}/api/oauth/token")
        oRequestHandler.setRequestType(1)
        oRequestHandler.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded')
        oRequestHandler.addParameters('client_id', config.plugins.iptvplayer.debridlink_ID.value)
        oRequestHandler.addParameters("refresh_token", refreshTok)
        oRequestHandler.addParameters("grant_type", "refresh_token")
        r = e2Json_loads(oRequestHandler.request())

        config.plugins.iptvplayer.debridlink_token.setValue(r["access_token"])
        config.plugins.iptvplayer.debridlink_token.save()

        configfile.save()
        return r["access_token"]
