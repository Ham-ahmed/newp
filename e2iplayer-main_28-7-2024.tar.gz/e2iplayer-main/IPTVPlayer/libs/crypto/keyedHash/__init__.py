# -*- coding: utf-8 -*-
""" crypto.keyedHash

    The keyedHash package.

    Copyright (c) 2002 by Paul A. Lambert
    Read LICENSE.txt for license information.
"""
