# build to simplify loading modules in e2iplayer scripts
#   from Plugins.Extensions.IPTVPlayer.compat import
#

try:
    from urllib.error import HTTPError as urllib2_HTTPError
    from urllib.error import URLError as urllib2_URLError
    from urllib.parse import quote as urllib_quote
    from urllib.parse import quote_plus as urllib_quote_plus
    from urllib.parse import unquote as urllib_unquote
    from urllib.parse import unquote_plus as urllib_unquote_plus
    from urllib.parse import urlencode as urllib_urlencode
    from urllib.request import BaseHandler as urllib2_BaseHandler
    from urllib.request import \
        HTTPBasicAuthHandler as urllib2_HTTPBasicAuthHandler
    from urllib.request import \
        HTTPCookieProcessor as urllib2_HTTPCookieProcessor
    from urllib.request import HTTPErrorProcessor as urllib2_HTTPErrorProcessor
    from urllib.request import HTTPHandler as urllib2_HTTPHandler
    from urllib.request import \
        HTTPRedirectHandler as urllib2_HTTPRedirectHandler
    from urllib.request import HTTPSHandler as urllib2_HTTPSHandler
    from urllib.request import ProxyHandler as urllib2_ProxyHandler
    from urllib.request import Request as urllib2_Request
    from urllib.request import addinfourl as urllib_addinfourl
    from urllib.request import build_opener as urllib2_build_opener
    from urllib.request import install_opener as urllib2_install_opener
    from urllib.request import urlopen as urllib2_urlopen
    from urllib.request import urlopen as urllib_urlopen
    from urllib.request import urlretrieve as urllib_urlretrieve
except Exception:
    print("UrlLib: import problem")

try:
    from urllib.parse import (parse_qs, parse_qsl, urljoin, urlparse, urlsplit,
                              urlunparse, urlunsplit)
except Exception:
    print("UrlParse: import problem")

try:
    from json import dump as e2Json_dump
    from json import dumps as e2Json_dumps
    from json import load as e2Json_load
    from json import loads as e2Json_loads
except Exception:
    from simplejson import dump as e2Json_dump
    from simplejson import dumps as e2Json_dumps
    from simplejson import load as e2Json_load
    from simplejson import loads as e2Json_loads
