# -*- coding: utf-8 -*-
from Components.config import config
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import \
    TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.libs.hcaptcha_2captcha import \
    UnCaptchahCaptcha as UnCaptchahCaptcha_2captcha
from Plugins.Extensions.IPTVPlayer.libs.recaptcha_mye2i import \
    UnCaptchaReCaptcha as UnCaptchaReCaptcha_mye2i
from Plugins.Extensions.IPTVPlayer.libs.recaptcha_v2 import \
    UnCaptchaReCaptcha as UnCaptchaReCaptcha_fallback
from Plugins.Extensions.IPTVPlayer.libs.recaptcha_v2_2captcha import \
    UnCaptchaReCaptcha as UnCaptchaReCaptcha_2captcha
from Plugins.Extensions.IPTVPlayer.libs.recaptcha_v2_9kw import \
    UnCaptchaReCaptcha as UnCaptchaReCaptcha_9kw
from Plugins.Extensions.IPTVPlayer.libs.recaptcha_v2_myjd import \
    UnCaptchaReCaptcha as UnCaptchaReCaptcha_myjd
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import GetDefaultLang
from Screens.MessageBox import MessageBox


class CaptchaHelper():

    def processCaptcha(self, sitekey, refUrl, bypassCaptchaService=None, userAgent=None, baseErrMsgTab=None, beQuaiet=False, captchaType=''):
        if isinstance(baseErrMsgTab, list):
            errorMsgTab = list(baseErrMsgTab)
        else:
            errorMsgTab = [_('Link protected with Google ReCaptcha v2')]

        if userAgent == None:
            try:
                userAgent = self.USER_AGENT
            except Exception:
                pass

        if userAgent == None:
            try:
                userAgent = self.defaultParams['header']['User-Agent']
            except Exception:
                pass

        recaptcha = UnCaptchaReCaptcha_fallback(lang=GetDefaultLang())
        recaptcha.HTTP_HEADER['Referer'] = refUrl
        if userAgent != None:
            recaptcha.HTTP_HEADER['User-Agent'] = userAgent
        token = recaptcha.processCaptcha(sitekey)

        if token == '':
            recaptcha = None
            if config.plugins.iptvplayer.captcha_bypass.value != '' and bypassCaptchaService == None:
                bypassCaptchaService = config.plugins.iptvplayer.captcha_bypass.value
            if bypassCaptchaService == '9kw.eu':
                recaptcha = UnCaptchaReCaptcha_9kw()
            elif bypassCaptchaService == '2captcha.com':
                if captchaType == 'h1':
                    recaptcha = UnCaptchahCaptcha_2captcha()
                else:
                    recaptcha = UnCaptchaReCaptcha_2captcha()
            elif bypassCaptchaService == 'mye2i':
                recaptcha = UnCaptchaReCaptcha_mye2i()
            elif config.plugins.iptvplayer.myjd_login.value != '' and config.plugins.iptvplayer.myjd_password.value != '':
                recaptcha = UnCaptchaReCaptcha_myjd()

            if recaptcha != None:
                token = recaptcha.processCaptcha(sitekey, refUrl, captchaType)
            else:
                errorMsgTab.append(_('Please visit http://zadmario.gitlab.io/captcha.html to learn how to redirect this task to the external device.'))
                if not beQuaiet:
                    self.sessionEx.waitForFinishOpen(MessageBox, '\n'.join(errorMsgTab), type=MessageBox.TYPE_ERROR, timeout=20)
                if bypassCaptchaService != None:
                    errorMsgTab.append(_(' or '))
                    errorMsgTab.append(_('You can use "http://2captcha.com/" or "https://9kw.eu/" services for automatic solution.') + ' ' + _('Go to the host configuration available under blue button.'))
        return token, errorMsgTab
