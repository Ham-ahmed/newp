# -*- coding: utf-8 -*-
#

from base64 import b64encode

from Components.ActionMap import ActionMap
from Components.config import config
from Components.Label import Label
from enigma import eConsoleAppContainer, eTimer
from Plugins.Extensions.IPTVPlayer.compat import e2Json_dumps, e2Json_loads
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import \
    TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import (E2PrioFix,
                                                           GetIconDir,
                                                           GetPluginDir,
                                                           GetPyScriptCmd,
                                                           byteify,
                                                           eConnectCallback,
                                                           getDebugMode,
                                                           printDBG, printExc)
from Screens.Screen import Screen


class UnCaptchaReCaptchaMyJDWidget(Screen):

    def __init__(self, session, title, sitekey, referer):
        self.session = session
        Screen.__init__(self, session)
        self.sitekey = sitekey
        self.referer = referer

        sz_w = 504  # getDesktop(0).size().width() - 190
        sz_h = 300  # getDesktop(0).size().height() - 195
        if sz_h < 500:
            sz_h += 4
        self.skin = f"""
            <screen position="center,center" title="{title}" size="{sz_w},{sz_h}">
             <ePixmap position="5,9"   zPosition="4" size="30,30" pixmap="{GetIconDir('red' + '.png')}" transparent="1" alphatest="on" />

             <widget name="label_red"    position="45,9"  zPosition="5" size="175,27" valign="center" halign="left" backgroundColor="black" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
             <widget name="title"        position="5,47"  zPosition="1" size="{sz_w - 135},23" font="Regular;20"            transparent="1"  backgroundColor="#00000000"/>
             <widget name="console"      position="10,{(sz_h - 160) / 2}" zPosition="2" size="{sz_w - 20},160" valign="center" halign="center"   font="Regular;24" transparent="0" foregroundColor="white" backgroundColor="black"/>
            </screen>"""

        self.onShown.append(self.onStart)
        self.onClose.append(self.__onClose)

        self["title"] = Label(" ")
        self["console"] = Label(" ")

        self["label_red"] = Label(_("Cancel"))

        self["actions"] = ActionMap(["ColorActions", "SetupActions", "WizardActions", "ListboxActions"],
                                    {
            "cancel": self.keyExit,
            # "ok"    : self.keyOK,
            "red": self.keyRed,
        }, -2)

        self.workconsole = {'console': None, 'close_conn': None, 'stderr_conn': None, 'stdout_conn': None, 'stderr': '', 'stdout': ''}
        self.result = ''

        self.timer = {'timer': eTimer(), 'is_started': False}
        self.timer['callback_conn'] = eConnectCallback(self.timer['timer'].timeout, self._timoutCallback)
        self.errorCodeSet = False

    def _timoutCallback(self):
        self.timer['is_started'] = False
        self.close(self.result)

    def __onClose(self):
        self.workconsole['close_conn'] = None
        self.workconsole['stderr_conn'] = None
        self.workconsole['stdout_conn'] = None
        if self.workconsole['console']:
            self.workconsole['console'].sendCtrlC()
        self.workconsole['console'] = None

        if self.timer['is_started']:
            self.timer['timer'].stop()
        self.timer['callback_conn'] = None
        self.timer = None

    def _scriptClosed(self, code=0):
        if code == 0:
            self["console"].setText(_('JDownloader script finished.'))
            self.close(self.result)
        elif not self.errorCodeSet:
            self["console"].setText(_(f"JDownloader script execution failed.\nError code: {code}\n"))

    def _scriptStderrAvail(self, data):
        self.workconsole['stderr'] += data
        self.workconsole['stderr'] = self.workconsole['stderr'].split('\n')
        if data.endswith('\n'):
            data = ''
        else:
            data = self.workconsole['stderr'].pop(-1)
        for line in self.workconsole['stderr']:
            if not (line := line.strip()):
                continue
            try:
                line = byteify(e2Json_loads(line))
                if line['type'] == 'captcha_result':
                    self.result = line['data']
                    # timeout timer
                    if self.timer['is_started']:
                        self.timer['timer'].stop()
                    # start timeout timer 3s
                    self.timer['timer'].start(3000, True)
                    self.timer['is_started'] = True
                    self["console"].setText(_('Captcha solved.\nWaiting for notification.'))
                elif line['type'] == 'status':
                    self["console"].setText(_(str(line['data'])))
                elif line['type'] == 'error':
                    if line['code'] == 500:
                        self["console"].setText(_('Invalid email.'))
                    elif line['code'] == 403:
                        self["console"].setText(_('Access denied. Please check password.'))
                    else:
                        self["console"].setText(_(f"Error code: {line['code']}\nError message: {line['data']}"))
                    self.errorCodeSet = True
            except Exception:
                printExc()
        self.workconsole['stderr'] = data

    def _scriptStdoutAvail(self, data):
        self.workconsole['stdout'] += data
        self.workconsole['stdout'] = self.workconsole['stdout'].split('\n')
        if data.endswith('\n'):
            data = ''
        else:
            data = self.workconsole['stdout'].pop(-1)
        for line in self.workconsole['stdout']:
            printDBG(line)
        self.workconsole['stdout'] = data

    def startExecution(self):
        login = config.plugins.iptvplayer.myjd_login.value
        password = config.plugins.iptvplayer.myjd_password.value
        jdname = config.plugins.iptvplayer.myjd_jdname.value

        captcha = {'siteKey': self.sitekey, 'sameOrigin': True, 'siteUrl': self.referer, 'contextUrl': '/'.join(self.referer.split('/')[:3]), 'boundToDomain': True, 'stoken': None}
        try:
            captcha = b64encode(e2Json_dumps(captcha))
        except Exception:
            printExc()
        if getDebugMode() == '':
            debug = 0
        else:
            debug = 1

        cmd = f'{GetPyScriptCmd("fakejd")} "{GetPluginDir("libs/")}" "{login}" "{password}" "{jdname}" "{captcha}" {debug}'

        self["console"].setText(_('JDownloader script execution'))

        self.workconsole['console'] = eConsoleAppContainer()
        self.workconsole['close_conn'] = eConnectCallback(self.workconsole['console'].appClosed, self._scriptClosed)
        self.workconsole['stderr_conn'] = eConnectCallback(self.workconsole['console'].stderrAvail, self._scriptStderrAvail)
        self.workconsole['stdout_conn'] = eConnectCallback(self.workconsole['console'].stdoutAvail, self._scriptStdoutAvail)
        self.workconsole["console"].execute(E2PrioFix(cmd, 0))
        printDBG(f">>> EXEC CMD [{cmd}]")

    def onStart(self):
        self.onShown.remove(self.onStart)
        self.startExecution()

    def keyExit(self):
        self.close(self.result)

    def keyRed(self):
        self.close(self.result)
