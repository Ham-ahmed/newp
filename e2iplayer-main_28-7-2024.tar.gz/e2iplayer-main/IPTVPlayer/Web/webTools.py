# -*- coding: utf-8 -*-

import os
import threading
import time
from importlib import import_module

from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import \
    TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import GetLogoDir

import settings

########################################################


def formSUBMITvalue(inputHiddenObjects, caption, input_style='', input_text=''):
    retTxt = f'\n<form method="GET">{input_text}'
    for inputObj in inputHiddenObjects:
        retTxt += f'<input type="hidden" name="{inputObj[0]}" value="{inputObj[1]}">'
    retTxt += f'<input type="submit" value="{caption}" {input_style}></form>\n'
    return retTxt
########################################################


def formSUBMITtext(caption, inputName, inputStyle='', inputValue=''):
    retTxt = '\n<form method="GET">'
    retTxt += f'<input type="text" name{inputName}" value="{inputValue}">'
    retTxt += f'<input type="submit" value="{caption}" {inputStyle}>'
    retTxt += '</form>\n'
    return retTxt
########################################################


def formSUBMITtextWithOptions(caption, inputName, inputStyle='', inputValue='', options=[]):
    retTxt = '\n<form method="GET">'
    retTxt += f'<input type="text" name{inputName}" value="{inputValue}">'
    retTxt += f'<input type="submit" value="{caption}" {inputStyle}>'
    for option in options:
        retTxt += f'<input type="radio" name="type" value="{option[0]}" {option[1]}>{option[2]}'
    retTxt += '</form>\n'
    return retTxt
########################################################


def formMultipleSearchesSUBMITtext(captions, inputName, inputStyle='', inputValue=''):
    retTxt = '\n<form method="GET">'
    retTxt += f'<input type="text" name="{inputName}" value="{inputValue}">'
    for caption in captions:
        tmp = f"{_('Search in ')}'{caption[0]}'"
        retTxt += f'<input type="submit" value="{tmp}" name="{caption[1]}" {inputStyle}>'
    retTxt += '</form>\n'
    return retTxt
########################################################


def formGET(radioList):
    radioList = radioList.strip()
    if radioList.endswith('</br>'):
        radioList = radioList[:-5]
    elif radioList.endswith('<br>'):
        radioList = radioList[:-4]
    if radioList.startswith('ERROR:'):
        return f'\n<a><font color="#FFE4C4">{radioList[6:]}</font></a>'
    elif radioList.count('<input type="radio"') == 1:
        return str(radioList)
    else:
        return f'\n<form method="GET">\n{radioList}\n<input type="submit" value="{_("Save")}"></form>\n'
########################################################


def tableHorizontalRedLine(colspan):
    retTxt = f'<tr><td colspan = "{colspan}" style="border: 1px solid red;"></td></tr>\n'
    return retTxt
########################################################


def removeSpecialChars(text):
    text = text.replace('\n', ' ').replace('\r', '').replace('\t', ' ').replace('"', "'").replace('  ', " ").strip()
    text = text.replace('&oacute;', 'ó').replace('&Oacute;', 'Ó')
    text = text.replace('&quot;', "'").replace('&#34;', "'").replace('&nbsp;', ' ').replace('&#160;', " ").replace('[/br]', "<br>")
    return text.strip()
########################################################


def getHostLogo(hostName):
    try:
        _temp = import_module(f'Plugins.Extensions.IPTVPlayer.hosts.host{hostName}')
        logo = _temp.IPTVHost().getLogoPath().value[0]
        _temp = None
        if os.path.exists(logo):
            logo = f'<img border="0" alt="hostLogo" src="./icons/logos/{logo.replace(GetLogoDir(), '')}" width="120" height="40">'
        else:
            raise Exception
    except Exception:
        if os.path.exists(GetLogoDir(f'{hostName}logo.png')):
            logo = f'<img border="0" alt="hostLogo" src="./icons/logos/{hostName}logo.png" width="120" height="40">'
        else:
            logo = ""
    return logo
########################################################


def initActiveHost(hostName):
    settings.activeHost = {}
    settings.retObj = None
    settings.currItem = {}

    if hostName is None:
        pass
    else:

        settings.activeHost['Name'] = hostName
        _temp = import_module(f'Plugins.Extensions.IPTVPlayer.hosts.host{hostName}')
        settings.activeHost['Title'] = _temp.gettytul()
        settings.activeHost['Obj'] = _temp.IPTVHost()
        settings.activeHost['PIC'] = settings.activeHost['Obj'].getLogoPath().value[0]
        settings.activeHost['SupportedTypes'] = settings.activeHost['Obj'].getSupportedFavoritesTypes().value
        settings.activeHost['PathLevel'] = 1
        settings.activeHost['Status'] = ''
        settings.retObj = settings.activeHost['Obj'].getInitList()
        settings.activeHost['ListType'] = 'ListForItem'
        settings.activeHost['SearchTypes'] = settings.activeHost['Obj'].getSearchTypes()
    return
########################################################


def isActiveHostInitiated():
    status = False
    try:
        if len(settings.activeHost.keys()) > 0:
            status = True
    except Exception as e:
        print('EXCEPTION in webTools:isActiveHostInitiated - ', str(e))
    return status
########################################################


def isCurrentItemSelected():
    status = False
    try:
        if len(settings.currItem.keys()) > 0:
            status = True
    except Exception as e:
        print('EXCEPTION in webTools:isCurrentItemSelected - ', str(e))
    return status
########################################################


def iSactiveHostsHTMLempty():
    if len(settings.activeHostsHTML.keys()) == 0:
        return True
    else:
        return False
########################################################


def isConfigsHTMLempty():
    if len(settings.configsHTML.keys()) == 0:
        return True
    else:
        return False
########################################################


def isNewHostListShown():
    return settings.NewHostListShown

########################################################


def setNewHostListShown(status):
    settings.NewHostListShown = status
########################################################


def isThreadRunning(name):
    status = False
    for i in threading.enumerate():
        print('isThreadRunning>running threads:', i.name)
        if name == i.name:
            status = True
    return status
########################################################


def stopRunningThread(name):
    settings.StopThreads = True
    for myThread in threading.enumerate():
        print('isThreadRunning>running threads:', myThread.name)
        if name == myThread.name:
            if (myThread.isAlive()):
                myThread.terminate()
    time.sleep(0.2)  # time for thread to close
    return isThreadRunning(name)
